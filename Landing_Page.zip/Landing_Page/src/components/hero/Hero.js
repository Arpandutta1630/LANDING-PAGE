import React from "react";
import "./Hero.css";
import heroImg from "../../assets/phone.svg";

const Hero = ({ myTheme }) => {
  return (
    <section className="hero" data-theme={myTheme}>
      <div className="container --grid-15">
        <div className="hero-text">
          <h1>Welcome to Bewakoof Shop Landing Page.</h1>
          <p>
          Only Bewakoof Shopping is an activity in which a customer browses the available goods or services presented by one or more retailers with the potential intent to purchase a suitable selection of them.
          </p>
          <div className="--flex-start">
            <button className="--btn btn-p">Learn More</button>
            <button className="--btn --btn-danger">Sign Up</button>
          </div>
        </div>
        <div className=" --text-center">
          <img src={heroImg} alt="phone" width={200} />
        </div>
      </div>
    </section>
  );
};

export default Hero;
